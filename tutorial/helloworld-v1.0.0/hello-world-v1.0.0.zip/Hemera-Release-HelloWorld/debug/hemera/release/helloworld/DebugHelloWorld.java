package hemera.release.helloworld;

import hemera.core.structure.runtime.util.DebugResourceNode;
import hemera.core.structure.runtime.util.RuntimeDebugger;

public class DebugHelloWorld {

	public static void main(final String[] args) throws Exception {
		// This is where we installed our Hemera environment.
		final RuntimeDebugger debugger = new RuntimeDebugger("/Workspace/Hemera/Local/");
		// Add a resource to debug.
		// final String classname = HelloWorldResource.class.getName();
		// final String configLocation = "/Workspace/Sourcecode/Project-Hemera/Hemera-Release-HelloWorld/config/hello-world.xml";
		// final String resourcesDir = "/Workspace/Sourcecode/Project-Hemera/Hemera-Release-HelloWorld/resources";
		// debugger.addResource(new DebugResourceNode(classname, configLocation, resourcesDir, null, null));
		// You may also debug directly via HBM file.
		debugger.addHBM("/Workspace/Sourcecode/Project-Hemera/Hemera-Release-HelloWorld/hello-world.hbm");
		// Start the debugger.
		debugger.start();
	}
}
