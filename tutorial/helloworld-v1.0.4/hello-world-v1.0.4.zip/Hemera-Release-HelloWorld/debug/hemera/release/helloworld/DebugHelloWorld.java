package hemera.release.helloworld;

import hemera.core.structure.runtime.util.RuntimeDebugger;
import hemera.core.utility.logging.LoggingConfig;

public class DebugHelloWorld {

	public static void main(final String[] args) throws Exception {
		// Disable logging file output.
		LoggingConfig.FileOutputEnabled.setValue(false);
		// This is where we installed our Hemera environment.
		final RuntimeDebugger debugger = new RuntimeDebugger("/Workspace/Hemera/Local/");
		// Add HBM file.
		debugger.addHBM("/Workspace/Sourcecode/Hemera/Hemera-Release-HelloWorld/hello-world.hbm");
		// Start the debugger.
		debugger.start();
	}
}
